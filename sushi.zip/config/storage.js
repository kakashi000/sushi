const FPersist = require('fpersist');

const fpersist = new FPersist('./storage');

module.exports = fpersist;
