/* eslint-disable no-restricted-syntax */
/* eslint-disable no-console */
const requireDir = require('require-dir');
const bot = require('./bot.js');
const storage = require('./config/storage.js');

const commands = requireDir('./discord_commands');

Object.keys(commands).forEach((key) => {
  bot.registerCommand(key, commands[key].action, commands[key].options);
});

bot.on('ready', async () => {
  console.log('Ready!');
  console.log(bot.commands);
  console.log(bot.guilds);
  /* for (const [id, guild] of bot.guilds) {
    // eslint-disable-next-line no-await-in-loop
    bot.registerGuildPrefix(id, await storage.getItem(guild.name));
  } */
});

bot.on('error', (err) => {
  console.warn(err);
});

bot.connect().then(
  bot.editStatus('online', {
    name: ';help',
    type: 0,
  }),
);
