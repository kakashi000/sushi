/* eslint-disable no-param-reassign */
const storage = require('../config/storage.js');
const bot = require('../bot.js');

const command = {};

command.name = 'prefix';

command.action = async (msg, args) => {
  bot.registerGuildPrefix(msg.channel.guild.id, args);
  await storage.editItem(msg.channel.guild.name, (guild) => {
    guild.prefix = args;
    return guild;
  }, msg.channel.guild);
  return msg.channel.createMessage(`The guild prefix is now set to \`${args.join(' ')}\`.`);
};

command.options = {
  argsRequired: true,
  description: 'Sets the guild prefix',
  errorMessage: 'Something went wrong with that command.',
  fullDescription: 'Say ;prefix [prefix] to set the guild prefix~',
  invalidUsageMessage: 'Say ;prefix [prefix] to set the guild prefix~',
};

module.exports = command;
